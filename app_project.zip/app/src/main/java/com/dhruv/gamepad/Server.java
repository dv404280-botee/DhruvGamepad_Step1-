package com.dhruv.gamepad;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.io.BufferedReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

/**
 * TV par chalne wali chhoti helper. ADB (shell) se start hoti hai:
 * CLASSPATH=dg.apk app_process /system/bin com.dhruv.gamepad.Server
 * Phone se text commands leti hai aur asli gamepad jaisa input TV mein inject karti hai.
 */
public class Server {
    public static final int PORT = 38555;
    public static final int VER = 6;
    static Object im;
    static Method inject;

    public static void main(String[] args) throws Exception {
        Class<?> c = Class.forName("android.hardware.input.InputManager");
        im = c.getDeclaredMethod("getInstance").invoke(null);
        inject = c.getMethod("injectInputEvent", InputEvent.class, int.class);
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        try {
            ss.bind(new InetSocketAddress(PORT));
        } catch (Exception e) {
            return;
        }
        while (true) {
            final Socket s = ss.accept();
            Thread t = new Thread(new Runnable() {
                public void run() {
                    handle(s);
                }
            });
            t.start();
        }
    }

    static void handle(Socket s) {
        try { Thread.currentThread().setPriority(Thread.MAX_PRIORITY); } catch (Throwable e) { }
        Set<Integer> down = new HashSet<Integer>();
        final boolean[] watch = new boolean[1];
        try {
            s.setTcpNoDelay(true);
            final OutputStream o = s.getOutputStream();
            o.write(("DG" + VER + "\n").getBytes());
            o.flush();
            final Socket sk = s;
            Thread ping = new Thread(new Runnable() {
                public void run() {
                    try {
                        while (!sk.isClosed()) {
                            Thread.sleep(1000);
                            synchronized (o) {
                                o.write("P\n".getBytes());
                                o.flush();
                            }
                        }
                    } catch (Throwable e) {
                        try { sk.close(); } catch (Throwable x) { }
                    }
                }
            });
            ping.setDaemon(true);
            ping.start();
            watch[0] = false;
            Thread fw = new Thread(new Runnable() {
                public void run() {
                    String last = "";
                    try {
                        while (!sk.isClosed()) {
                            Thread.sleep(2500);
                            if (!watch[0]) {
                                last = "";
                                continue;
                            }
                            String pk = focusPkg();
                            if (pk != null && !pk.equals(last)) {
                                last = pk;
                                synchronized (o) {
                                    o.write(("F " + pk + "\n").getBytes());
                                    o.flush();
                                }
                            }
                        }
                    } catch (Throwable e) {
                        // band
                    }
                }
            });
            fw.setDaemon(true);
            fw.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.trim().split(" ");
                if (p.length == 0) continue;
                if (p[0].equals("K") && p.length >= 3) {
                    int code = Integer.parseInt(p[1]);
                    boolean d = p[2].equals("1");
                    if (d) {
                        down.add(code);
                        key(code, true);
                    } else {
                        down.remove(code);
                        key(code, false);
                    }
                } else if (p[0].equals("H")) {
                    new Thread(new Runnable() {
                        public void run() {
                            try {
                                Runtime.getRuntime().exec(new String[]{"sh", "-c", "am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1"}).waitFor();
                            } catch (Throwable e) { }
                        }
                    }).start();
                } else if (p[0].equals("R") && p.length >= 3) {
                    rkey(Integer.parseInt(p[1]), p[2].equals("1"));
                } else if (p[0].equals("A") && p.length >= 7) {
                    axes(f(p[1]), f(p[2]), f(p[3]), f(p[4]), f(p[5]), f(p[6]));
                } else if (p[0].equals("C") && p.length >= 2) {
                    typeChar((char) Integer.parseInt(p[1]));
                } else if (p[0].equals("T") && p.length >= 2) {
                    synchronized (o) {
                        o.write(("T " + p[1] + "\n").getBytes());
                        o.flush();
                    }
                } else if (p[0].equals("W") && p.length >= 2) {
                    watch[0] = p[1].equals("1");
                } else if (p[0].equals("Q")) {
                    System.exit(0);
                }
            }
        } catch (Throwable e) {
            // connection toot gaya
        } finally {
            for (Integer code : down) key(code, false);
            axes(0, 0, 0, 0, 0, 0);
            try {
                s.close();
            } catch (Throwable e) {
            }
        }
    }

    static final Pattern FOCUS = Pattern.compile("\\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$]+\\}");

    /** TV par abhi kaun si app/game saamne hai (package naam), nahi mila to null. */
    static String focusPkg() {
        try {
            Process pr = Runtime.getRuntime().exec(new String[]{"sh", "-c", "dumpsys window | grep mCurrentFocus"});
            BufferedReader br = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            String ln, res = null;
            while ((ln = br.readLine()) != null) {
                Matcher m = FOCUS.matcher(ln);
                if (m.find()) res = m.group(1);
            }
            try { pr.waitFor(); } catch (Throwable e) { }
            try { pr.destroy(); } catch (Throwable e) { }
            return res;
        } catch (Throwable e) {
            return null;
        }
    }

    static float f(String v) {
        return Integer.parseInt(v) / 1000f;
    }

    static void key(int code, boolean down) {
        long now = SystemClock.uptimeMillis();
        KeyEvent e = new KeyEvent(now, now, down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                code, 0, 0, -1, 0, 0, 0x00000401);
        send(e);
    }

    /** TV remote ke buttons: asli remote/keyboard jaisa (source = keyboard), jaise `input keyevent`. */
    static void rkey(int code, boolean down) {
        long now = SystemClock.uptimeMillis();
        KeyEvent e = new KeyEvent(now, now, down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                code, 0, 0, -1, 0, 0, 0x00000101);
        send(e);
    }

    static void axes(float lx, float ly, float rx, float ry, float lt, float rt) {
        long now = SystemClock.uptimeMillis();
        MotionEvent.PointerProperties pp = new MotionEvent.PointerProperties();
        pp.id = 0;
        pp.toolType = MotionEvent.TOOL_TYPE_UNKNOWN;
        MotionEvent.PointerCoords pc = new MotionEvent.PointerCoords();
        pc.clear();
        pc.setAxisValue(MotionEvent.AXIS_X, lx);
        pc.setAxisValue(MotionEvent.AXIS_Y, ly);
        pc.setAxisValue(MotionEvent.AXIS_Z, rx);
        pc.setAxisValue(MotionEvent.AXIS_RZ, ry);
        pc.setAxisValue(MotionEvent.AXIS_RX, rx);
        pc.setAxisValue(MotionEvent.AXIS_RY, ry);
        pc.setAxisValue(MotionEvent.AXIS_LTRIGGER, lt);
        pc.setAxisValue(MotionEvent.AXIS_RTRIGGER, rt);
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_MOVE, 1,
                new MotionEvent.PointerProperties[]{pp}, new MotionEvent.PointerCoords[]{pc},
                0, 0, 1f, 1f, -1, 0, 0x01000010, 0);
        send(ev);
        ev.recycle();
    }

    static void typeChar(char ch) {
        try {
            KeyCharacterMap kcm = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD);
            KeyEvent[] evs = kcm.getEvents(new char[]{ch});
            if (evs == null) return;
            long now = SystemClock.uptimeMillis();
            for (int i = 0; i < evs.length; i++) {
                KeyEvent k = evs[i];
                KeyEvent e = new KeyEvent(now, now, k.getAction(), k.getKeyCode(), 0,
                        k.getMetaState(), -1, 0, 0, InputDevice.SOURCE_KEYBOARD);
                send(e);
            }
        } catch (Throwable t) {
            // ignore
        }
    }

    static void send(InputEvent e) {
        try {
            inject.invoke(im, e, 0);
        } catch (Throwable t) {
            // ignore
        }
    }
}
