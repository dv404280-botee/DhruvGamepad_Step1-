package com.dhruv.gamepad

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import dadb.AdbKeyPair
import dadb.Dadb
import android.widget.LinearLayout
import java.io.File
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var bar: LinearLayout
    private var onGamepad = false
    private val io = Executors.newSingleThreadExecutor()
    private var dadb: Dadb? = null
    private var ip = "192.168.43.158"

    // PS5 button -> Android key code
    private val keys = mapOf(
        "CROSS" to 96, "CIRCLE" to 97, "SQUARE" to 99, "TRIANGLE" to 100,
        "L1" to 102, "R1" to 103, "L2" to 104, "R2" to 105,
        "OPTIONS" to 108, "CREATE" to 109, "PS" to 3, "MUTE" to 164,
        "UP" to 19, "DOWN" to 20, "LEFT" to 21, "RIGHT" to 22, "TOUCHPAD" to 23
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ip = getSharedPreferences("dg", 0).getString("ip", ip) ?: ip

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                if (url.endsWith("index.html")) {
                    onGamepad = true
                    v.evaluateJavascript(HOOK, null)
                } else {
                    onGamepad = false
                    runOnUiThread { bar.visibility = View.GONE }
                }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.visibility = View.GONE

        val btn = TextView(this)
        btn.textSize = 13f
        btn.text = "\uD83D\uDCFA TV jodo"
        btn.setTextColor(Color.WHITE)
        btn.setBackgroundColor(Color.parseColor("#CC1C4C94"))
        btn.setPadding(26, 12, 26, 12)
        btn.setOnClickListener { findAndConnect() }
        btn.setOnLongClickListener { askIp(); true }
        bar.addView(btn)

        status = TextView(this)
        status.textSize = 11f
        status.setTextColor(Color.parseColor("#8FCBFF"))
        status.setBackgroundColor(Color.parseColor("#99000000"))
        status.setPadding(18, 12, 18, 12)
        status.text = "TV abhi juda nahi"
        bar.addView(status)

        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        lp.setMargins(8, 8, 0, 0)
        root.addView(bar, lp)

        setContentView(root)
        web.loadUrl("file:///android_asset/splash.html")
    }

    private fun setStatus(t: String) = runOnUiThread { status.text = t }

    private fun askIp() {
        val et = EditText(this)
        et.setText(ip)
        AlertDialog.Builder(this)
            .setTitle("TV ka IP address")
            .setView(et)
            .setPositiveButton("Jodo") { _, _ ->
                ip = et.text.toString().trim()
                getSharedPreferences("dg", 0).edit().putString("ip", ip).apply()
                dadb = null
                connect()
            }
            .setNegativeButton("Ruko", null)
            .show()
    }

    private fun nice(e: Throwable): String {
        val m = (e.message ?: e.toString()).lowercase()
        return when {
            m.contains("refused") -> "TV ka network ADB (port 5555) band hai"
            m.contains("timed out") || m.contains("timeout") -> "TV jawab nahi de raha (IP ya hotspot check karo)"
            m.contains("unreachable") -> "TV tak raasta nahi (same hotspot par ho?)"
            m.contains("auth") -> "TV par 'Allow' nahi dabaya"
            else -> e.javaClass.simpleName + ": " + m.take(50)
        }
    }

    private fun connect() {
        setStatus("TV se jod raha hun... TV par Allow dabao")
        io.execute {
            try {
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(ip, 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok")
                dadb = d
                setStatus("TV juda \u2713 $ip")
            } catch (e: Throwable) {
                dadb = null
                setStatus("TV nahi juda \u2717 " + nice(e))
            }
        }
    }

    // network par TV dhoondo (port 5555 kholne wale device)
    private fun findAndConnect() {
        setStatus("TV dhoondh raha hun...")
        io.execute {
            try {
                val prefixes = LinkedHashSet<String>()
                val mine = HashSet<String>()
                val en = NetworkInterface.getNetworkInterfaces()
                while (en != null && en.hasMoreElements()) {
                    val ni = en.nextElement()
                    if (!ni.isUp || ni.isLoopback) continue
                    for (a in ni.interfaceAddresses) {
                        val ad = a.address
                        if (ad is Inet4Address && ad.isSiteLocalAddress) {
                            val h = ad.hostAddress ?: continue
                            mine.add(h)
                            prefixes.add(h.substringBeforeLast('.'))
                        }
                    }
                }
                if (prefixes.isEmpty()) prefixes.add(ip.substringBeforeLast('.'))
                val hosts = ArrayList<String>()
                for (p in prefixes) for (i in 1..254) hosts.add("$p.$i")
                val found = java.util.Collections.synchronizedList(ArrayList<String>())
                val pool = java.util.concurrent.Executors.newFixedThreadPool(48)
                val latch = CountDownLatch(hosts.size)
                for (h in hosts) {
                    pool.execute {
                        try {
                            if (!mine.contains(h)) {
                                val so = Socket()
                                so.connect(InetSocketAddress(h, 5555), 600)
                                so.close()
                                found.add(h)
                            }
                        } catch (e: Throwable) {
                        } finally { latch.countDown() }
                    }
                }
                latch.await(25, TimeUnit.SECONDS)
                pool.shutdownNow()
                if (found.isEmpty()) {
                    setStatus("TV nahi mila \u2717 TV par network ADB (5555) khula nahi dikha")
                    return@execute
                }
                ip = if (found.contains(ip)) ip else found[0]
                getSharedPreferences("dg", 0).edit().putString("ip", ip).apply()
                setStatus("TV mila $ip, jod raha hun... TV par Allow dabao")
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(ip, 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok")
                dadb = d
                setStatus("TV juda \u2713 $ip")
            } catch (e: Throwable) {
                dadb = null
                setStatus("TV nahi juda \u2717 " + nice(e))
            }
        }
    }

    private fun press(code: Int) {
        io.execute {
            try {
                var d = dadb
                if (d == null) { return@execute }
                d.shell("input keyevent $code")
            } catch (e: Throwable) {
                dadb = null
                setStatus("TV juda nahi raha ✗ (TV jodo dabao)")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun key(name: String) { keys[name]?.let { press(it) } }
        @JavascriptInterface fun showBar() { runOnUiThread { bar.visibility = View.VISIBLE } }
        @JavascriptInterface fun replay() { runOnUiThread { web.loadUrl("file:///android_asset/splash.html") } }
    }

    override fun onBackPressed() {
        // controller par back dabane se animation wapas aati hai (START ke saath)
        if (onGamepad) web.loadUrl("file:///android_asset/splash.html")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onDestroy() {
        super.onDestroy()
        try { dadb?.close() } catch (e: Throwable) {}
        io.shutdown()
    }

    companion object {
        // controller page ke har button dabne par TV ko key bhejo
        const val HOOK = """
        (function(){
          if(window.__dgHook)return;window.__dgHook=1;
          document.addEventListener('pointerdown',function(e){
            var b=e.target.closest&&e.target.closest('.b');
            if(b&&b.getAttribute('data-id'))Android.key(b.getAttribute('data-id'));
          },true);
          var p=document.getElementById('panel');
          if(p&&!document.getElementById('dgreplay')){
            var b=document.createElement('button');b.id='dgreplay';b.className='tst';
            b.textContent='\u25B6 Animation dobara chalao';b.style.cssText='width:100%;margin:8px 0';
            b.onclick=function(){Android.replay();};
            var q=p.querySelector('.quick');
            if(q&&q.parentNode)q.parentNode.insertBefore(b,q.nextSibling);else p.appendChild(b);
          }
          Android.showBar();
        })();
        """
    }
}
