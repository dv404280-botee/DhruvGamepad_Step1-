package com.dhruv.gamepad

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private val io = Executors.newSingleThreadExecutor()
    private var dadb: Dadb? = null
    private var ip = "192.168.43.158"

    // PS5 button -> Android key code
    private val keys = mapOf(
        "CROSS" to 96, "CIRCLE" to 97, "SQUARE" to 99, "TRIANGLE" to 100,
        "L1" to 102, "R1" to 103, "L2" to 104, "R2" to 105,
        "OPTIONS" to 108, "CREATE" to 109, "PS" to 3, "MUTE" to 164,
        "UP" to 19, "DOWN" to 20, "LEFT" to 21, "RIGHT" to 22, "TOUCHPAD" to 23
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ip = getSharedPreferences("dg", 0).getString("ip", ip) ?: ip

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                if (url.endsWith("index.html")) v.evaluateJavascript(HOOK, null)
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        status = TextView(this)
        status.textSize = 11f
        status.setTextColor(Color.parseColor("#8FCBFF"))
        status.setBackgroundColor(Color.parseColor("#99000000"))
        status.setPadding(18, 8, 18, 8)
        status.text = "TV: tap karke jodo"
        status.visibility = View.GONE
        status.setOnClickListener { askIp() }
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        lp.setMargins(8, 8, 0, 0)
        root.addView(status, lp)

        setContentView(root)
        web.loadUrl("file:///android_asset/splash.html")
        connect()
    }

    private fun setStatus(t: String) = runOnUiThread { status.text = t }

    private fun askIp() {
        val et = EditText(this)
        et.setText(ip)
        AlertDialog.Builder(this)
            .setTitle("TV ka IP address")
            .setView(et)
            .setPositiveButton("Jodo") { _, _ ->
                ip = et.text.toString().trim()
                getSharedPreferences("dg", 0).edit().putString("ip", ip).apply()
                dadb = null
                connect()
            }
            .setNegativeButton("Ruko", null)
            .show()
    }

    private fun connect() {
        setStatus("TV: jod raha hun... TV par 'Allow' dabao")
        io.execute {
            try {
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(ip, 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok")
                dadb = d
                setStatus("TV juda ✓ $ip")
            } catch (e: Throwable) {
                dadb = null
                setStatus("TV nahi juda ✗ (tap karo) " + (e.message ?: "").take(60))
            }
        }
    }

    private fun press(code: Int) {
        io.execute {
            try {
                var d = dadb
                if (d == null) { return@execute }
                d.shell("input keyevent $code")
            } catch (e: Throwable) {
                dadb = null
                setStatus("TV nahi juda ✗ (tap karo)")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun key(name: String) { keys[name]?.let { press(it) } }
        @JavascriptInterface fun showBar() { runOnUiThread { status.visibility = View.VISIBLE } }
    }

    override fun onBackPressed() {
        // back button se app band na ho jaye galti se
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onDestroy() {
        super.onDestroy()
        try { dadb?.close() } catch (e: Throwable) {}
        io.shutdown()
    }

    companion object {
        // controller page ke har button dabne par TV ko key bhejo
        const val HOOK = """
        (function(){
          if(window.__dgHook)return;window.__dgHook=1;
          document.addEventListener('pointerdown',function(e){
            var b=e.target.closest&&e.target.closest('.b');
            if(b&&b.getAttribute('data-id'))Android.key(b.getAttribute('data-id'));
          },true);
          Android.showBar();
        })();
        """
    }
}
