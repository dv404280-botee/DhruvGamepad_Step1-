package com.dhruv.gamepad

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import dadb.AdbKeyPair
import dadb.Dadb
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var onGamepad = false
    private val io = Executors.newSingleThreadExecutor()
    private val slow = Executors.newFixedThreadPool(3)

    @Volatile private var dadb: Dadb? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var sock: Socket? = null
    @Volatile private var mode = 0 // 0 = juda nahi, 1 = fast helper, 2 = slow (input keyevent)
    private val q = LinkedBlockingQueue<String>()
    private val ax = DoubleArray(6) // lx ly rx ry lt rt
    @Volatile private var axDirty = false
    private var ip = "192.168.43.158"
    @Volatile private var rsMode = 0 // 0 = menu (D-pad jaisa), 1 = game (asli stick)
    @Volatile private var rsDir = 0
    @Volatile private var watchOn = false

    // PS5 button -> Android key code
    private val keys = mapOf(
        "CROSS" to 96, "CIRCLE" to 97, "SQUARE" to 99, "TRIANGLE" to 100,
        "L1" to 102, "R1" to 103, "L2" to 104, "R2" to 105,
        "OPTIONS" to 108, "CREATE" to 109, "PS" to 3, "MUTE" to 164,
        "UP" to 19, "DOWN" to 20, "LEFT" to 21, "RIGHT" to 22, "TOUCHPAD" to 23
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ip = getSharedPreferences("dg", 0).getString("ip", ip) ?: ip
        rsMode = getSharedPreferences("dg", 0).getInt("rs", 0)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String) {
                if (url.endsWith("index.html")) {
                    onGamepad = true
                    v.evaluateJavascript(HOOK, null)
                } else {
                    onGamepad = false
                }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        web.loadUrl("file:///android_asset/splash.html")
        startWriter()
        startMonitor()
    }

    // ---------- JS ko status bhejna ----------
    private fun st(text: String, state: String) {
        runOnUiThread {
            web.evaluateJavascript(
                "window.dgTv&&window.dgTv.st(" + JSONObject.quote(text) + ",'" + state + "')", null
            )
        }
    }

    private fun nice(e: Throwable): String {
        val m = (e.message ?: e.toString()).lowercase()
        return when {
            m.contains("refused") -> "TV ne connection mana kiya (USB debugging ON karo)"
            m.contains("timed out") || m.contains("timeout") -> "TV jawab nahi de raha (IP ya hotspot check karo)"
            m.contains("unreachable") -> "TV tak raasta nahi (same hotspot par ho?)"
            m.contains("auth") -> "TV par 'Allow' nahi dabaya"
            else -> e.javaClass.simpleName + ": " + m.take(60)
        }
    }

    // ---------- Phone -> TV bhejne wala writer (tez, alag thread) ----------
    private fun axisLine(): String {
        synchronized(ax) {
            return "A " + (ax[0] * 1000).toInt() + " " + (ax[1] * 1000).toInt() + " " +
                (ax[2] * 1000).toInt() + " " + (ax[3] * 1000).toInt() + " " +
                (ax[4] * 1000).toInt() + " " + (ax[5] * 1000).toInt() + "\n"
        }
    }

    private fun setAx(i: Int, v: Double) {
        synchronized(ax) { ax[i] = v }
        axDirty = true
    }

    private fun startWriter() {
        val t = Thread {
            while (true) {
                try {
                    val l = q.poll(8, TimeUnit.MILLISECONDS)
                    val o = out
                    if (o != null) {
                        var w = false
                        if (l != null) {
                            o.write(l.toByteArray())
                            w = true
                        }
                        if (axDirty) {
                            axDirty = false
                            o.write(axisLine().toByteArray())
                            w = true
                        }
                        if (w) o.flush()
                    }
                } catch (e: Throwable) {
                    out = null
                    if (mode == 1) {
                        mode = 0
                        st("TV se connection toot gaya ✗ (TV jodo dabao)", "err")
                    }
                }
            }
        }
        t.isDaemon = true
        t.start()
    }

    // dheema mode mein TV band ho jaye to pata chale
    private fun startMonitor() {
        val t = Thread {
            while (true) {
                try {
                    Thread.sleep(4000)
                    if (mode == 2 && !reach(ip, 5555)) {
                        mode = 0
                        st("TV se connection toot gaya \u2717 (TV jodo dabao)", "err")
                    }
                } catch (e: Throwable) { }
            }
        }
        t.isDaemon = true
        t.start()
    }

    // TV par saamne wali app ka naam JS ko dena (game-wise layout ke liye)
    private fun appFocus(pkg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.dgApp&&window.dgApp(" + JSONObject.quote(pkg) + ")", null)
        }
    }

    private fun dirKey(d: Int): Int = when (d) { 1 -> 19; 2 -> 20; 3 -> 21; else -> 22 }

    // right stick "menu mode": stick ko D-pad ki tarah chalao
    private fun rsMenu(x: Double, y: Double) {
        val m = Math.hypot(x, y)
        val d = if (m < 0.55) 0 else if (Math.abs(x) > Math.abs(y)) (if (x > 0) 4 else 3) else (if (y > 0) 2 else 1)
        if (d != rsDir) {
            if (rsDir != 0 && mode == 1) q.offer("K " + dirKey(rsDir) + " 0\n")
            rsDir = d
            if (d != 0 && mode == 1) q.offer("K " + dirKey(d) + " 1\n")
        }
    }

    private fun key(n: String, down: Boolean) {
        val code = keys[n] ?: return
        if (n == "L2") setAx(4, if (down) 1.0 else 0.0)
        if (n == "R2") setAx(5, if (down) 1.0 else 0.0)
        if (mode == 1) {
            q.offer("K " + code + " " + (if (down) 1 else 0) + "\n")
        } else if (mode == 2 && down) {
            slow.execute {
                try { dadb?.shell("input keyevent $code") } catch (e: Throwable) { }
            }
        }
    }

    // ---------- TV se jodna ----------
    private fun reach(host: String, port: Int): Boolean {
        return try {
            val s = Socket()
            s.connect(InetSocketAddress(host, port), 700)
            s.close()
            true
        } catch (e: Throwable) {
            false
        }
    }

    private fun scan(): String? {
        val prefixes = LinkedHashSet<String>()
        val mine = HashSet<String>()
        val en = NetworkInterface.getNetworkInterfaces()
        while (en != null && en.hasMoreElements()) {
            val ni = en.nextElement()
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.interfaceAddresses) {
                val ad = a.address
                if (ad is Inet4Address && ad.isSiteLocalAddress) {
                    val h = ad.hostAddress ?: continue
                    mine.add(h)
                    prefixes.add(h.substringBeforeLast('.'))
                }
            }
        }
        if (prefixes.isEmpty()) prefixes.add(ip.substringBeforeLast('.'))
        val hosts = ArrayList<String>()
        for (p in prefixes) for (i in 1..254) hosts.add("$p.$i")
        val helper = java.util.Collections.synchronizedList(ArrayList<String>())
        val adb = java.util.Collections.synchronizedList(ArrayList<String>())
        val pool = Executors.newFixedThreadPool(48)
        val latch = CountDownLatch(hosts.size)
        for (h in hosts) {
            pool.execute {
                try {
                    if (!mine.contains(h)) {
                        if (reach(h, 38555)) helper.add(h)
                        else if (reach(h, 5555)) adb.add(h)
                    }
                } catch (e: Throwable) {
                } finally {
                    latch.countDown()
                }
            }
        }
        latch.await(25, TimeUnit.SECONDS)
        pool.shutdownNow()
        return if (helper.isNotEmpty()) helper[0] else if (adb.isNotEmpty()) adb[0] else null
    }

    private fun openSock(host: String): Boolean {
        var s: Socket? = null
        try {
            s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, Server.PORT), 800)
            s.soTimeout = 1500
            val ins = s.getInputStream()
            val sb = StringBuilder()
            while (true) {
                val c = ins.read()
                if (c < 0 || c == 10) break
                sb.append(c.toChar())
                if (sb.length > 10) break
            }
            if (sb.toString() != "DG" + Server.VER) {
                try { s.getOutputStream().write("Q\n".toByteArray()) } catch (e: Throwable) { }
                s.close()
                return false
            }
            s.soTimeout = 3500
            try { sock?.close() } catch (e: Throwable) { }
            val mine = s
            sock = mine
            out = mine.getOutputStream()
            mode = 1
            if (watchOn) q.offer("W 1\n")
            val rd = Thread {
                try {
                    val ins = mine.getInputStream()
                    val lb = StringBuilder()
                    while (true) {
                        val c = ins.read()
                        if (c < 0) break
                        if (c == 10) {
                            val ln = lb.toString()
                            lb.setLength(0)
                            if (ln.startsWith("F ")) appFocus(ln.substring(2).trim())
                        } else if (lb.length < 200) {
                            lb.append(c.toChar())
                        }
                    }
                } catch (e: Throwable) { }
                if (sock === mine) {
                    out = null
                    mode = 0
                    st("TV se connection toot gaya \u2717 (TV jodo dabao)", "err")
                    try { mine.close() } catch (e: Throwable) { }
                }
            }
            rd.isDaemon = true
            rd.start()
            return true
        } catch (e: Throwable) {
            try { s?.close() } catch (x: Throwable) { }
            return false
        }
    }

    private fun connectTv() {
        io.execute {
            try {
                st("TV dhoondh raha hun...", "wait")
                var target = ip
                if (!reach(target, Server.PORT) && !reach(target, 5555)) {
                    val f = scan()
                    if (f == null) {
                        st("TV nahi mila ✗ TV par USB debugging ON hai? Hotspot same hai?", "err")
                        return@execute
                    }
                    target = f
                    ip = f
                    getSharedPreferences("dg", 0).edit().putString("ip", f).apply()
                }
                if (openSock(target)) {
                    st("TV juda ✓ tez mode ($target)", "ok")
                    return@execute
                }
                st("TV par 'Allow' dabao (agar poochhe)...", "wait")
                val priv = File(filesDir, "adbkey")
                val pub = File(filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create(target, 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok")
                try { dadb?.close() } catch (e: Throwable) { }
                dadb = d
                st("TV mein helper daal raha hun...", "wait")
                try {
                    val apk = File(applicationInfo.sourceDir)
                    d.push(apk, "/data/local/tmp/dg.apk", 420, apk.lastModified())
                    Thread.sleep(500)
                    d.shell("CLASSPATH=/data/local/tmp/dg.apk nohup app_process /system/bin com.dhruv.gamepad.Server >/dev/null 2>&1 &")
                    for (i in 0 until 14) {
                        Thread.sleep(400)
                        if (openSock(target)) {
                            st("TV juda ✓ tez mode ($target)", "ok")
                            return@execute
                        }
                    }
                } catch (e: Throwable) {
                }
                mode = 2
                st("TV juda ✓ dheema mode ($target)", "ok")
            } catch (e: Throwable) {
                st(nice(e), "err")
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun kd(n: String) { key(n, true) }
        @JavascriptInterface fun ku(n: String) { key(n, false) }
        @JavascriptInterface fun axis(k: String, x: Double, y: Double) {
            if (k == "LS") { synchronized(ax) { ax[0] = x; ax[1] = y }; axDirty = true }
            else if (k == "RS") {
                if (rsMode == 1) { synchronized(ax) { ax[2] = x; ax[3] = y }; axDirty = true }
                else rsMenu(x, y)
            }
        }
        @JavascriptInterface fun setRs(m: Int) {
            if (rsMode == 0 && rsDir != 0 && mode == 1) q.offer("K " + dirKey(rsDir) + " 0\n")
            rsDir = 0
            synchronized(ax) { ax[2] = 0.0; ax[3] = 0.0 }; axDirty = true
            rsMode = m
            getSharedPreferences("dg", 0).edit().putInt("rs", m).apply()
        }
        @JavascriptInterface fun getRs(): Int = rsMode
        @JavascriptInterface fun watch(on: Boolean) {
            watchOn = on
            if (mode == 1) q.offer("W " + (if (on) 1 else 0) + "\n")
        }
        @JavascriptInterface fun type(del: Int, add: String) {
            if (mode != 1) { st("Keyboard ke liye 'tez mode' chahiye (TV jodo dabao)", "err"); return }
            for (i in 0 until Math.min(del, 200)) { q.offer("K 67 1\n"); q.offer("K 67 0\n") }
            for (ch in add.take(200)) q.offer("C " + ch.code + "\n")
        }
        @JavascriptInterface fun enter() {
            if (mode == 1) { q.offer("K 66 1\n"); q.offer("K 66 0\n") }
            else st("Keyboard ke liye 'tez mode' chahiye (TV jodo dabao)", "err")
        }
        @JavascriptInterface fun perms() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 23) {
                    requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO, android.Manifest.permission.READ_PHONE_STATE), 11)
                } else {
                    Toast.makeText(this@MainActivity, "Is phone par permission pehle se mili hui hai", Toast.LENGTH_SHORT).show()
                }
            }
        }
        @JavascriptInterface fun tv() { connectTv() }
        @JavascriptInterface fun setIp(v: String) {
            ip = v.trim()
            getSharedPreferences("dg", 0).edit().putString("ip", ip).apply()
            connectTv()
        }
        @JavascriptInterface fun getIp(): String = ip
        @JavascriptInterface fun getMode(): Int = mode
        @JavascriptInterface fun replay() {
            runOnUiThread { web.loadUrl("file:///android_asset/splash.html") }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        var ok = grantResults.isNotEmpty()
        for (g in grantResults) if (g != PackageManager.PERMISSION_GRANTED) ok = false
        Toast.makeText(this, if (ok) "Permission mil gayi \u2713" else "Kuch permission nahi mili", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        // controller par back dabane se animation wapas aati hai (START ke saath)
        if (onGamepad) web.loadUrl("file:///android_asset/splash.html")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onDestroy() {
        super.onDestroy()
        try { sock?.close() } catch (e: Throwable) { }
        try { dadb?.close() } catch (e: Throwable) { }
        io.shutdown()
        slow.shutdown()
    }

    companion object {
        // controller page ke buttons aur sticks ko TV tak pahunchana + TV icon load karna
        const val HOOK = """
        (function(){
          if(window.__dgHook)return;window.__dgHook=1;
          window.addEventListener('dgbtn',function(e){var d=e.detail;if(d.down)Android.kd(d.id);else Android.ku(d.id);});
          window.addEventListener('dgstick',function(e){var d=e.detail;Android.axis(d.k,d.x,d.y);});
          var s=document.createElement('script');s.src='tv.js';document.head.appendChild(s);
        })();
        """
    }
}
