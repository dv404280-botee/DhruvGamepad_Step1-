/* TV icon + chhota box (sirf APK ke andar). Settings icon ke saath chhupta/dikhta hai. */
(function(){
if(window.dgTv)return;
var css=document.createElement('style');
css.textContent=[
'#tvbtn{position:fixed;top:8px;left:max(8px,env(safe-area-inset-left,0px));z-index:7;background:#0A111F;color:#E6E8EE;border:1px solid #2F7FD6;border-radius:10px;padding:10px 12px;min-height:44px;display:flex;align-items:center;gap:6px;font:13px system-ui,sans-serif;animation:gearIn .5s cubic-bezier(.2,1.4,.4,1) both;transition:transform .12s,border-color .12s,background .12s,box-shadow .12s}',
'#tvbtn svg{width:22px;height:22px;display:block}',
'#tvbtn:active{transform:scale(.9)}',
'#tvdot{width:9px;height:9px;border-radius:50%;background:#6b7280;box-shadow:0 0 0 rgba(0,0,0,0)}',
'#tvdot.ok{background:#3ddc84;box-shadow:0 0 8px #3ddc84}',
'#tvdot.wait{background:#ffb74d;animation:tvblink .8s infinite}',
'#tvdot.err{background:#ff5252;box-shadow:0 0 8px #ff5252}',
'@keyframes tvblink{50%{opacity:.25}}',
'@keyframes slideD{from{opacity:0;transform:translateY(-16px) scale(.96)}to{opacity:1;transform:none}}',
'#tvbox{position:fixed;top:60px;left:max(8px,env(safe-area-inset-left,0px));width:min(300px,64vw);max-height:calc(100% - 132px);overflow-y:auto;z-index:9;background:#0D0F14;border:1px solid #2F7FD6;border-radius:14px;padding:12px 14px;box-sizing:border-box;color:#E6E8EE;font:13px system-ui,sans-serif;animation:slideD .3s cubic-bezier(.2,.8,.3,1) both;touch-action:pan-y}',
'#tvbox h2{margin:0 0 8px;font-size:16px;font-weight:600}',
'#tvst{margin:0 0 10px;font-size:12.5px;color:#8FCBFF;line-height:1.35;word-break:break-word}',
'#tvbox button{width:100%;margin-top:7px;background:#0A111F;color:#E6E8EE;border:1px solid #2F7FD6;border-radius:10px;padding:11px;font:14px system-ui,sans-serif;transition:transform .12s,box-shadow .12s,border-color .12s,background .12s}',
'#tvbox button.pri{background:#1C4C94;border-color:#8FCBFF}',
'#tvbox .r{display:flex;gap:6px;margin-top:7px}',
'#tvbox .r button{margin-top:0;width:auto;flex:0 0 38%}',
'#tvip{flex:1;min-width:0;background:#0A111F;color:#E6E8EE;border:1px solid #2F7FD6;border-radius:10px;padding:10px;font:14px system-ui,sans-serif;outline:none;transition:box-shadow .15s,border-color .15s}',
'#tvip:focus{border-color:#8FCBFF;box-shadow:0 0 14px rgba(77,163,255,.85)}',
'#tvbtn.pg,#tvbox button.pg{border-color:#8FCBFF!important;background:#14274A!important;box-shadow:0 0 16px rgba(77,163,255,.9)!important}',
'#tvbox button:active{transform:scale(.96);box-shadow:0 0 14px rgba(77,163,255,.8)}',
'#corner2{position:fixed;top:0;left:0;width:72px;height:72px;z-index:7}',
'#tvbox .lb{margin:10px 0 0;font-size:12px;color:#B4B2A9}',
'#tvbox .sg{display:flex;gap:6px;margin-top:5px}',
'#tvbox .sg button{margin-top:0;padding:9px 4px;font-size:13px}',
'#tvbox .sg button.on{background:#1C4C94;border-color:#8FCBFF}',
'#kbtab{position:fixed;right:max(8px,env(safe-area-inset-right,0px));bottom:8px;z-index:10;width:46px;height:46px;border-radius:50%;background:#0A111F;color:#8FCBFF;border:1px solid #2F7FD6;display:flex;align-items:center;justify-content:center;padding:0;animation:gearIn .5s cubic-bezier(.2,1.4,.4,1) both;transition:transform .25s,bottom .25s,border-color .12s,box-shadow .12s}',
'#kbtab svg{width:22px;height:22px;transition:transform .25s}',
'#kbtab.open{bottom:8px}',
'#mictab{position:fixed;right:calc(max(8px,env(safe-area-inset-right,0px)) + 54px);bottom:8px;z-index:10;width:46px;height:46px;border-radius:50%;background:#0A111F;color:#8FCBFF;border:1px solid #2F7FD6;display:flex;align-items:center;justify-content:center;padding:0;transition:transform .2s cubic-bezier(.2,1.4,.4,1)}',
'#mictab:active{transform:scale(.86)}',
'#mictab[hidden]{display:none}',
'#tvms{font-size:11px;font-variant-numeric:tabular-nums;color:#9aa4b2;min-width:0}',
'#tvms.g{color:#3ddc84}#tvms.y{color:#ffb74d}#tvms.r{color:#ff5252}',
'#tvsig{margin:-4px 0 8px;font-size:12px;color:#9aa4b2}',
'#kbtab.open svg{transform:rotate(180deg)}',
'#kbtab:active{transform:scale(.88)}',
'#kbtab.pg{border-color:#8FCBFF!important;background:#14274A!important;box-shadow:0 0 16px rgba(77,163,255,.9)!important}',
'#kbtab[hidden]{display:none}',
'#panel{bottom:64px!important}',
'#tvbtn[hidden],#tvbox[hidden],#corner2[hidden]{display:none}',
'@media (prefers-reduced-motion:reduce){#tvbtn,#tvbox{animation:none}}'
].join('\n');
document.head.appendChild(css);

var btn=document.createElement('button');btn.id='tvbtn';btn.type='button';btn.setAttribute('aria-label','TV');
btn.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="#8FCBFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5" width="19" height="12.5" rx="2"/><path d="M8 21h8M12 17.5V21"/><path d="M9 11.2l2.2 2.2 3.8-4" stroke="#6FB8FF"/></svg><span id="tvdot"></span><span id="tvms"></span>';
var box=document.createElement('div');box.id='tvbox';box.hidden=true;
box.innerHTML='<h2>TV se jodo</h2><div id="tvst">Abhi juda nahi</div><div id="tvsig"></div>'+
'<button id="tvgo" class="pri" type="button">TV dhoondo aur jodo</button>'+
'<div class="r"><input id="tvip" type="text" inputmode="decimal" placeholder="TV IP" autocomplete="off"><button id="tvipgo" type="button">IP se jodo</button></div>'+
'<div class="lb">Right stick:</div><div class="sg" id="rssg"><button data-m="0" type="button">Menu (D-pad jaisa)</button><button data-m="1" type="button">Game (asli stick)</button></div>'+
'<button id="tvtest" type="button">Test: TV mein Right phir Left</button>'+
'<button id="tvrem" type="button">\uD83D\uDCFA TV Remote (Volume, Home, Back)</button>'+
'<button id="tvx" type="button">Band karo</button>';
var c2=document.createElement('div');c2.id='corner2';c2.hidden=true;
document.body.appendChild(btn);document.body.appendChild(box);document.body.appendChild(c2);

var dot=document.getElementById('tvdot'),stEl=document.getElementById('tvst'),ipEl=document.getElementById('tvip');
var msEl=document.getElementById('tvms'),sigEl=document.getElementById('tvsig');
window.dgTv={st:function(t,s){stEl.textContent=t;dot.className=s||'';},
 rtt:function(m){if(m<0){msEl.textContent='';msEl.className='';sigEl.textContent='';if(dot.className==='ok')dot.className='';return;}if(dot.className!=='ok')dot.className='ok';var c=m<35?'g':m<90?'y':'r';msEl.textContent=m+'ms';msEl.className=c;sigEl.textContent='Signal: '+m+' ms \u00B7 '+(m<35?'Badhiya':m<90?'Theek':'Kamzor (hotspot ke paas aao)');}};
function A(f){try{return f();}catch(e){}}
btn.addEventListener('click',function(){
  if(box.hidden){ipEl.value=A(function(){return Android.getIp();})||'';box.hidden=false;}else box.hidden=true;
});
document.getElementById('tvgo').addEventListener('click',function(){A(function(){Android.tv();});});
document.getElementById('tvipgo').addEventListener('click',function(){var v=(ipEl.value||'').trim();if(v)A(function(){Android.setIp(v);});});
function tap(id,delay){setTimeout(function(){A(function(){Android.kd(id);});setTimeout(function(){A(function(){Android.ku(id);});},90);},delay);}
document.getElementById('tvtest').addEventListener('click',function(){tap('RIGHT',0);tap('LEFT',450);});
document.getElementById('tvrem').addEventListener('click',function(){box.hidden=true;if(window.dgRemote)window.dgRemote(true);});
var rsB=document.querySelectorAll('#rssg button');
function rsShow(){var m=A(function(){return Android.getRs();});rsB.forEach(function(b){b.classList.toggle('on',+b.dataset.m===m);});}
rsB.forEach(function(b){b.addEventListener('click',function(){A(function(){Android.setRs(+b.dataset.m);});rsShow();});});
btn.addEventListener('click',rsShow);
document.getElementById('tvx').addEventListener('click',function(){box.hidden=true;});
/* tap par chamak */
document.addEventListener('pointerdown',function(e){var t=e.target.closest&&e.target.closest('#tvbtn,#tvbox button,#kbtab,#dgreplay,#dgperm');if(t){t.classList.remove('pg');void t.offsetWidth;t.classList.add('pg');setTimeout(function(){t.classList.remove('pg');},520);}},true);

/* settings icon ke saath hi chhupna / dikhna */
var gear=document.getElementById('gear'),corner=document.getElementById('corner'),hg=document.getElementById('hideGear');
if(hg)hg.textContent='Settings aur TV icon chhupao';
function sync(){var h=!!(gear&&gear.hidden);btn.hidden=h;kbt.hidden=h;mic.hidden=h;fab.hidden=h;if(h)box.hidden=true;c2.hidden=!h;}
if(gear){new MutationObserver(sync).observe(gear,{attributes:true,attributeFilter:['hidden']});}

/* bayen kone mein 3 baar tap = wapas */
var taps=[];
c2.addEventListener('pointerdown',function(e){e.preventDefault();var t=Date.now();taps=taps.filter(function(x){return t-x<1200;});taps.push(t);
  if(taps.length>=3){taps=[];if(gear)gear.hidden=false;if(corner)corner.hidden=true;}});

/* settings mein: animation dobara + permission */
var panel=document.getElementById('panel');
if(panel){
  var rp=document.createElement('button');rp.id='dgreplay';rp.type='button';rp.textContent='\u25B6 Animation dobara chalao';
  var pm=document.createElement('button');pm.id='dgperm';pm.type='button';pm.textContent='Permission do (Mic / Phone)';
  [rp,pm].forEach(function(b){b.style.cssText='width:100%;margin:8px 0 0;flex:none';});
  rp.addEventListener('click',function(){A(function(){Android.replay();});});
  pm.addEventListener('click',function(){A(function(){Android.perms();});});
  var q=panel.querySelector('.quick');
  if(q&&q.parentNode){q.parentNode.insertBefore(pm,q.nextSibling);q.parentNode.insertBefore(rp,q.nextSibling);}else{panel.appendChild(rp);panel.appendChild(pm);}
}
/* keyboard: niche daayen kone mein upar-teer. phone par likho = TV mein likhta hai */
var kb=document.getElementById('kbbar'),kt=document.getElementById('kbtext');
var kbt=document.createElement('button');kbt.id='kbtab';kbt.type='button';kbt.setAttribute('aria-label','Keyboard');
kbt.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="#8FCBFF" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V6M6 11l6-6 6 6"/></svg>';
document.body.appendChild(kbt);
var mic=document.createElement('button');mic.id='mictab';mic.type='button';mic.className='mic';mic.setAttribute('aria-label','Bolkar likho');
mic.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="#8FCBFF" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3"/><path class="w" d="M2.5 9v5"/><path class="w w2" d="M21.5 9v5"/></svg>';
document.body.appendChild(mic);
var fab=document.createElement('button');fab.id='remfab';fab.type='button';fab.setAttribute('aria-label','TV Remote');
fab.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="#8FCBFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2.5" width="10" height="19" rx="4"/><circle cx="12" cy="8" r="2"/><path d="M10 13h4M10 16.5h4"/></svg>';
document.body.appendChild(fab);
fab.addEventListener('click',function(){if(window.dgRemote)window.dgRemote(true);});
mic.addEventListener('click',function(){if(window.dgListen)window.dgListen();});
function kbShow(on){if(!kb)return;if(on){if(panel)panel.hidden=true;box.hidden=true;kb.hidden=false;kbt.classList.add('open');setTimeout(function(){try{kt.focus();}catch(x){}},60);}else{kb.hidden=true;kbt.classList.remove('open');try{kt.blur();}catch(x){}}}
kbt.addEventListener('click',function(){kbShow(kb.hidden);});
window.dgKb=function(){kbShow(kb.hidden);};
var kbc=document.getElementById('kbclose');if(kbc)kbc.addEventListener('click',function(){kbt.classList.remove('open');});
var kbo=document.getElementById('kbopen');if(kbo)kbo.addEventListener('click',function(){kbt.classList.add('open');});
var prev='';
window.addEventListener('dgtext',function(e){
  var t=(e.detail&&e.detail.text)||'',p=0,n=Math.min(prev.length,t.length);
  while(p<n&&prev.charAt(p)===t.charAt(p))p++;
  var del=prev.length-p,add=t.slice(p);prev=t;
  if(del||add)A(function(){Android.type(del,add);});
});
window.addEventListener('dgenter',function(){A(function(){Android.enter();});});
if(kb&&!kb.hidden)kbt.classList.add('open');
sync();
})();
if(window.dgRecolor)window.dgRecolor();
