(function(){
if(window.__dgHook)return;window.__dgHook=1;
var A=window.Android;if(!A)return;
function $(id){return document.getElementById(id);}
/* ---------- buttons: dabate hi down, chhodte hi up ---------- */
var act={};
document.addEventListener('pointerdown',function(e){
  var b=e.target.closest&&e.target.closest('.b');
  if(b){var id=b.getAttribute('data-id');if(id){act[e.pointerId]=id;try{A.down(id);}catch(x){}}}
},true);
function rel(e){var id=act[e.pointerId];if(id){delete act[e.pointerId];try{A.up(id);}catch(x){}}}
document.addEventListener('pointerup',rel,true);
document.addEventListener('pointercancel',rel,true);
document.addEventListener('lostpointercapture',rel,true);
/* ---------- sticks: analog values ---------- */
var st={},ax={LS:[0,0],RS:[0,0]},pend=false;
function flush(){pend=false;try{A.axis(ax.LS[0],ax.LS[1],ax.RS[0],ax.RS[1]);}catch(x){}}
function qf(){if(!pend){pend=true;requestAnimationFrame(flush);}}
function nrm(s,e){
  var r=s.firstElementChild.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,u=r.width/2/35;
  var dx=(e.clientX-cx)/(12*u),dy=(e.clientY-cy)/(12*u),d=Math.hypot(dx,dy);
  if(d>1){dx/=d;dy/=d;d=1;}
  if(d<.12){dx=0;dy=0;}
  return [dx,dy];
}
document.addEventListener('pointerdown',function(e){
  var s=e.target.closest&&e.target.closest('.stick');if(!s||!s.parentNode)return;
  var k=s.parentNode.getAttribute('data-k');if(k!=='LS'&&k!=='RS')return;
  st[e.pointerId]={k:k,s:s};ax[k]=nrm(s,e);qf();
},true);
document.addEventListener('pointermove',function(e){
  var o=st[e.pointerId];if(!o)return;ax[o.k]=nrm(o.s,e);qf();
},true);
function stUp(e){var o=st[e.pointerId];if(!o)return;delete st[e.pointerId];ax[o.k]=[0,0];qf();}
document.addEventListener('pointerup',stUp,true);
document.addEventListener('pointercancel',stUp,true);
document.addEventListener('lostpointercapture',stUp,true);
/* app se bahar jaate hi sab chhod do */
document.addEventListener('visibilitychange',function(){if(document.hidden){act={};st={};ax={LS:[0,0],RS:[0,0]};try{A.releaseAll();}catch(x){}}});
/* ---------- Settings mein: animation dobara ---------- */
var p=$('panel');
if(p&&!$('dgreplay')){
  var b=document.createElement('button');b.id='dgreplay';b.type='button';b.className='tst';
  b.textContent='▶ Animation dobara chalao';b.style.cssText='width:100%;margin:8px 0;flex:none';
  b.onclick=function(){A.replay();};
  var q=p.querySelector('.quick');
  if(q&&q.parentNode)q.parentNode.insertBefore(b,q.nextSibling);else p.appendChild(b);
}
/* ---------- TV icon + chhota box ---------- */
var css=document.createElement('style');
css.textContent=
'#tvbtn{position:fixed;top:8px;left:max(8px,env(safe-area-inset-left,0px));z-index:7;width:46px;height:46px;border-radius:10px;border:1px solid #2F7FD6;background:#0A111F;color:#E6E8EE;display:flex;align-items:center;justify-content:center;padding:0;animation:tvIn .5s cubic-bezier(.2,1.4,.4,1) both;transition:transform .12s,border-color .12s,background .12s}'+
'#tvbtn:active{transform:scale(.9)}#tvbtn svg{width:24px;height:24px;display:block}'+
'#tvbtn.ok{border-color:#3DDC97;box-shadow:0 0 10px rgba(61,220,151,.5)}#tvbtn.ok svg{stroke:#3DDC97}'+
'#tvbox{position:fixed;top:62px;left:max(8px,env(safe-area-inset-left,0px));z-index:7;width:min(270px,58vw);box-sizing:border-box;background:#0D0F14;border:1px solid #2F7FD6;border-radius:14px;padding:12px;color:#E6E8EE;font:14px system-ui,sans-serif;animation:tvDown .32s cubic-bezier(.2,.8,.3,1) both}'+
'#tvbtn[hidden],#tvbox[hidden]{display:none}'+
'#tvbox h4{margin:0 0 6px;font-size:15px;font-weight:600}'+
'#tvst{font-size:12px;color:#8FCBFF;margin:0 0 8px;line-height:1.35;min-height:16px;word-break:break-word}#tvst.ok{color:#3DDC97}#tvst.bad{color:#FF7A85}'+
'#tvbox button{width:100%;background:#0A111F;color:#E6E8EE;border:1px solid #2F7FD6;border-radius:10px;padding:10px;font:14px system-ui,sans-serif;margin-top:6px;transition:box-shadow .12s,background .12s}'+
'#tvbox button:active{background:#14274A;border-color:#8FCBFF;box-shadow:0 0 12px rgba(77,163,255,.7)}'+
'#tvbox .r{display:flex;gap:6px;margin-top:6px}#tvbox .r input{flex:1;min-width:0;background:#060910;color:#E6E8EE;border:1px solid #2F7FD6;border-radius:10px;padding:9px;font:15px system-ui,sans-serif;user-select:text;-webkit-user-select:text}'+
'#tvbox .r input:focus{outline:none;border-color:#8FCBFF;box-shadow:0 0 12px rgba(77,163,255,.7)}#tvbox .r button{width:auto;margin:0;padding:9px 12px}'+
'@keyframes tvIn{from{opacity:0;transform:translateX(-34px) scale(.6)}to{opacity:1;transform:none}}'+
'@keyframes tvDown{from{opacity:0;transform:translateY(-34px)}to{opacity:1;transform:none}}'+
'@media (prefers-reduced-motion:reduce){#tvbtn,#tvbox{animation:none}}';
document.head.appendChild(css);
var tb=document.createElement('button');tb.id='tvbtn';tb.type='button';tb.className='tvb';tb.setAttribute('aria-label','TV');
tb.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="#E6E8EE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4.5" width="19" height="12.5" rx="2.2"/><path d="M8 20.5h8M12 17v3.5"/></svg>';
var bx=document.createElement('div');bx.id='tvbox';bx.hidden=true;
bx.innerHTML='<h4>📺 TV se jodo</h4><div id="tvst">TV abhi juda nahi</div>'+
'<button id="tvfind" type="button">🔍 TV dhoondo aur jodo</button>'+
'<div class="r"><input id="tvip" type="text" inputmode="decimal" placeholder="TV ka IP" autocomplete="off"><button id="tvgo" type="button">Jodo</button></div>'+
'<button id="tvstick" type="button">🕹 Stick: Analog</button>';
document.body.appendChild(tb);document.body.appendChild(bx);
$('tvip').value=A.getIp?A.getIp():'';
tb.addEventListener('click',function(){bx.hidden=!bx.hidden;});
$('tvfind').addEventListener('click',function(){A.find();});
$('tvgo').addEventListener('click',function(){A.connectIp($('tvip').value.trim());});
var dp=false;try{dp=localStorage.getItem('dgStickDp')==='1';}catch(x){}
function stk(){$('tvstick').textContent=dp?'🕹 Stick: D-Pad (menu)':'🕹 Stick: Analog (game)';try{A.stickMode(dp);}catch(x){}}
$('tvstick').addEventListener('click',function(){dp=!dp;try{localStorage.setItem('dgStickDp',dp?'1':'0');}catch(x){}stk();});stk();
window.dgStatus=function(t,ok){var s=$('tvst');if(!s)return;s.textContent=t;s.className=ok===1?'ok':(ok===0?'bad':'');tb.classList.toggle('ok',ok===1);};
/* Settings icon chhupe to TV icon bhi chhupe; 3 tap par dono wapas */
var g=$('gear');
function sync(){var h=!!(g&&g.hidden);tb.hidden=h;if(h)bx.hidden=true;}
sync();
if(g&&window.MutationObserver)new MutationObserver(sync).observe(g,{attributes:true,attributeFilter:['hidden']});
try{A.ready();}catch(x){}
})();
